﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StopWatch : MonoBehaviour
{
    public float timer;
    float milliseconds,seconds,minutes;

    [SerializeField] Text stopWatchText = null;
    private bool flag;  //for the timer status: counting or not

    // Start is called before the first frame update
    void Start()
    {
        timer = 0;
        flag = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(flag == true)
            StopWatchWork();
    }

    void StopWatchWork()    //time transformation
    {
        timer += Time.deltaTime;
        milliseconds = (int)(timer * 1000f) % 1000;
        seconds = (int)(timer % 60);
        minutes = (int)(timer / 60);

        stopWatchText.text = minutes.ToString("00") + ":" + seconds.ToString("00") + "." + milliseconds.ToString("000");
    }

    public string getStringTime()   //time as a string
    {
        return (minutes.ToString("00") + ":" + seconds.ToString("00") + "." + milliseconds.ToString("000"));
    }

    public void StartStopWatch()    //start timer
    {
        flag = true;
    }

    public void StartFromLosing()   //in the case of losing: restart timer only if it was already counting before
    {
        if(timer != 0)
            flag = true;
    }

    public void StopStopWatch()     //stop timer
    {
        flag = false;
    }

    public void ResetStopWatch()    //reset timer
    {
        flag = false;
        timer = 0;
        stopWatchText.text = "00:00.000";
    }
}
