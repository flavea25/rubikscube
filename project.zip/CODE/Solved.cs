﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Solved : MonoBehaviour
{
    public ReadCube readCube;
    public CubeState cubeState;
    public PanelLogic winningPanel, basicPanel, losingPanel;
    public StopWatch stopWatch;

    // Start is called before the first frame update
    void Start()
    {
        readCube = FindObjectOfType<ReadCube>();
        cubeState = FindObjectOfType<CubeState>();
    }

    public void SolvedCheck()
    {
        readCube.ReadState();
        string moveString = cubeState.GetStateString(); //cube state as a string
        if(string.Equals(moveString,"UUUUUUUUURRRRRRRRRFFFFFFFFFDDDDDDDDDLLLLLLLLLBBBBBBBBB"))  //is solved
        {
            if(stopWatch.timer!=0)  //the cube is solved because someone solved it after it was shuffled
            {
                stopWatch.StopStopWatch();
                winningPanel.OpenPanel(stopWatch);
                stopWatch.ResetStopWatch();
            }
            else    //the cube is solved as in the default mode; or someone shuffled the cube themseleves and solved it after
                basicPanel.OpenPanel();
        }
        else //the cube is unsolved
        {
            stopWatch.StopStopWatch();
            losingPanel.OpenPanel();
        }
    }

    public void RemovePanel()
    {
        winningPanel.RemovePanel();
    }
}
