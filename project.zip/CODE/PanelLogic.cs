﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PanelLogic : MonoBehaviour
{
    [SerializeField] Text panelText = null;

    public void OpenPanel()
    {
        gameObject.SetActive(true);
    }

    public void OpenPanel(StopWatch stopWatch)  //only called by the winning panel
    {
        string temp = "You finished the cube in \n";
        panelText.text = temp + stopWatch.getStringTime();
        gameObject.SetActive(true);
    }

    public void RemovePanel()
    {
        gameObject.SetActive(false);
    }
}
