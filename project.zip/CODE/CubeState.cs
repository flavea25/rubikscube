﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeState : MonoBehaviour
{
    // sides
    public List<GameObject> front = new List<GameObject>();
    public List<GameObject> back = new List<GameObject>();
    public List<GameObject> up = new List<GameObject>();
    public List<GameObject> down = new List<GameObject>();
    public List<GameObject> left = new List<GameObject>();
    public List<GameObject> right = new List<GameObject>();

    public static bool autoRotating = false;
    public static bool started = false;

    public void PickUp(List<GameObject> cubeSide)  //select a side
    {
        foreach (GameObject face in cubeSide)
            if (face != cubeSide[4])    //match the face with the middle piece
                face.transform.parent.transform.parent = cubeSide[4].transform.parent;
    }    

    public void PutDown(List<GameObject> smallCubes, Transform pivot)   //release the side
    {
        foreach (GameObject smallCube in smallCubes)
            if (smallCube != smallCubes[4])
                smallCube.transform.parent.transform.parent = pivot;
    }

    string GetSideString(List<GameObject> side)     //returns a string of the colors met on that side
    {
        string sideString = "";
        foreach (GameObject face in side)
            sideString += face.name[0].ToString();  //the first char of the color
        return sideString;
    }

    public string GetStateString()  //same as above, for the whole cube
    {
        string stateString = "";
        stateString += GetSideString(up);
        stateString += GetSideString(right);
        stateString += GetSideString(front);
        stateString += GetSideString(down);
        stateString += GetSideString(left);
        stateString += GetSideString(back);
        return stateString;
    }
}
